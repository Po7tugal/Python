from random import randint 

resposta = False 

print("_____ Vamos Jogar um jogo, Adivinhe o número gerado _____\n")

while resposta == False:

    jogoAcabou = False 
    tentativa = 0 
    numero_aleatorio = randint(1, 100) 
    pontuacao = 0 
    pontuacoes = [100,80,60,40,30,20,10]
    tentouNovamente = False

    while jogoAcabou == False and tentativa < 7:
        if not tentouNovamente:
            num_inserido = int(input("Chute seu número: "))
        
        if num_inserido >= 1 and num_inserido <= 100: 
            tentativa += 1 
            
            if numero_aleatorio > num_inserido:
                print("O número aleatório é maior") 
            elif numero_aleatorio < num_inserido:
                print("O número aleatório é menor")
            else:
                jogoAcabou = True
                print(f"Você acertou em {tentativa} tentativas!!!")   
            tentouNovamente = False    
        else:
            while num_inserido < 1 or num_inserido > 100:
                print("O número inserido não é permitido!! Deve ser entre 1 e 100") 
                num_inserido = int(input("Chute seu número: ")) 
                tentouNovamente = True

    if jogoAcabou: 
        pontuacao = pontuacoes[tentativa-1]

    else:
        print(f"Fim de jogo! Você não conseguiu adivinhar. O número era {numero_aleatorio}.")

    print(f"Sua pontuação atual é {pontuacao}")

    if input("Deseja jogar novamente? (S/N): ").upper() != "S":
        resposta = True
