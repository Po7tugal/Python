nums = [2,5,8,11,7,9,13]

print(nums)
# Imprimir um elemento da lista
print(nums[2])
# Inserir um elemento no final da lista
nums.append(22)
# Inserir varios elementos na lista
nums.extend([12,16])
# Inserir em posição específica
nums.insert(3,29) # 3 = posição // 29 = num inserido

# Remover um elemento no final da lista
nums.pop()
# Remover um elemento de uma posição específica pelo índice
nums.pop(2)
# Inserir um elemento em uma posição específica pelo valor
nums.remove(17)
# nº de elementos da lista
total = len(nums)

for n in nums:
    if n <= 5:
        print(n, end=" ")

for indice in range(len(nums)):
    if nums[indice] <= 10:
        print(nums[indice], end=" ")