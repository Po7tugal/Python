from random import randint

lista = []
pares = 0
impares = 0
media = 0
maiorMed = 0
listaMaiorMedia = []

for n in range(30):
    numero_aleatorio = randint(1, 100) 
    lista.append(numero_aleatorio)
    media = (sum(lista)/len(lista))
    
    if lista[n] % 2 == 0:
        pares += 1
    else: 
        impares += 1

    if lista[n] > media:
        maiorMed += 1
        listaMaiorMedia.append(numero_aleatorio)

print(lista)
print(f"Existem {pares} Números pares")
print(f"Existem {impares} Números ímpares")
print(f"O Maior número da lista é {max(lista)}")
print(f"O Menor número da lista é {min(lista)}")
print(f"A média dos números da lista é {round(media)}")
print(f"{maiorMed} números são maiores que a média")
print(listaMaiorMedia)